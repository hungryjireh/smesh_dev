// function myFunction() {
//     $('#checkbox').change(function() {
//         $.post("/toggle/", {
//             id: '{{workexperiance.id}}', 
//             isworking: this.checked, 
//             csrfmiddlewaretoken: '{{ csrf_token }}' 
//         });
//     });
// }